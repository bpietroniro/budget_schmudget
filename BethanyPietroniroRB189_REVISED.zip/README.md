# RB189 Project: "Budget Schmudget"

## Specifications

For this project I used:

- Ruby v. 3.1.2
- Bundler v. 2.3.24
- PostgreSQL 14.5 (Homebrew)
- Google Chrome Version 108.0.5359.124 for testing

## Setup

To set up the project:

1. Download and unzip the project files into a directory of your choice.
2. Enter the directory called "budgetapp" from the command line and run `bundle install`.
3. Execute the file  `schema.sql` by running  the following  command: `psql -d [database] < schema.sql`, where `[database]` is any database you currently have set up in Postgres on your system.

### Note about the database

The file `schema.sql` will only create the database and its schema, and will not populate it with any data. The data will be created from the app, and the process for doing this will (I hope!) be intuitive.

**However**, one important point to note: I've included a database table called `budgets`, and in its current state the app only uses *one row* of this table. The app is hardcoded for that row to **have an `id` value of 1.** 

This should happen automatically as long as the sequence `budget_id_seq` isn't altered before starting the application. But if there are any issues with the application, it might be worth checking to make sure that the command `SELECT * FROM budgets` returns a single row where the value of the `id` column is 1.

I set things up this way because I originally intended for multiple "budget objects" per user (one for every month of a year, say). Though I started building with this in mind, I quickly realized that it would majorly violate the "Don't go overboard" instruction for the assessment.

For ease of transition, and also to lay the groundwork for further work I'd like to do later on with this project for practice, I left the "budgets" table in there along with some bits of an infrastructure that uses `budget id` to look things up and otherwise get stuff done. My hope is that this is all neatly contained within the application logic and shouldn't cause any problems.

## Running the application

After running `bundle install` successfully, to start the app run `ruby budget.rb` from the command line. (This should work, but if there's any issue you could try `bundle exec ruby budget.rb`. )

From your browser (Chrome recommended), navigate to `localhost:4567`. 

### Username and Password

Once you click "Get Started", you should be prompted for a username and password. The login credentials are:

​	username: **Hailey**     password: **SweetDeetEmpire**

(Yes, this is a dorky shoutout to my lovely and limitlessly patient and supportive partner, who test-ran the app and listened to me complain about bugs for days.)

I haven't implemented user registration, multiple users, or secure password storage in this application, because the assessment didn't specify that we should. I heaped this into the category of "don't go overboard".

You can sign out at any time with the "Sign Out" button at the top right of any page other than the home page. Navigating to any other page while signed out should require authentication first, and on successful authentication should then reroute you to the page you requested.

### Setting up a budget

To begin, enter a desire budget total. This is the last time you'll see the setup page, but you edit your total later on.

My hope is that navigating the application should be pretty straightforward from here on out, and I've included some comments in the code, but if anything doesn't  make sense, please don't hesitate to reach out to me!

Once you've added a category, it will appear on the `"/budget"` page. To view, edit, and log expenses to a category you can click on its name. (This might not be immediately obvious to a new user.)

## Process, Thoughts, Tradeoffs

### Modularity

There's some code repetition in `budget.rb`, particularly involving input validation errors. I couldn't find an easy way to modularize this, and would be especially grateful for any suggestions.

### Optimization

I tried to avoid N + 1 queries, and wound up pushing more application logic to the database than I originally intended. I think this turned out okay, but made me realize I have no idea how things would work on a larger scale. 

The biggest question marks came for me with the challenge of pagination. I wasn't sure whether it would be better to load all the items into `budget.rb` and handle pagination there, or to do so with a database query. In the end I did it with the database, but I don't know if that was the best choice.

### User Interface

I did put significant time and effort into the HTML/CSS of this project, even though it wasn't required, mainly because these are new to me as well and I wanted to practice them and try out some things. I also found that it was easier for me to tackle out the logic of the application once I had a sense of what things would look like.

I probably overused Flexbox, because I wanted to learn it better. 

There are also lots of design details that I abandoned (like consistency of sizing and centering) in favor of getting things to work. Just mentioning this here so that you know that I know. :)

## Thank you!

That's all I can think of for now! Thank you so much for taking the time to review this project; I hope you enjoy it!
